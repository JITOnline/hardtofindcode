#include "fgconi.h"

FGConnectionInterface::~FGConnectionInterface()
{
}
