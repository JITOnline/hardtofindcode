// fgfpicki.cc

#include "fgfpicki.h"

FGFilePickerInterface::FGFilePickerInterface(FGConnectionInterface* pConnIf)
: mpConnIf(pConnIf)
{
}
