// fgfncomp.cc

#include "fgfncomp.h"

FGFileNameComponent::~FGFileNameComponent()
{
}
